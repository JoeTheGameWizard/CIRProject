using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor.Rendering;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PlayerHealth : MonoBehaviour
{
    [SerializeField]
    private int MaxHealth;
    [SerializeField]
    private int CurrentHealth;
    [Space(10)]

    [SerializeField]
    private DamageType[] Vunerabilities;
    [SerializeField]
    private DamageType[] Resistances;
    [SerializeField]
    private DamageType[] Immunities;
    [Space(20)]

    [SerializeField]
    private Image HealthBar;
    [SerializeField]
    private Image HealthBarAfterImage;
    [SerializeField]
    private float AfterImageSpeed;
    [SerializeField]
    private TextMeshProUGUI HealthText;
    [Space(10)]

    [SerializeField]
    private Transform SpawnPoint;
    [SerializeField]
    private GameObject DeathUI;

    private float AfterImageLevel;
    private InputManager InputManager;

    private void Start()
    {
        InputManager = GetComponent<InputManager>();
    }

    public void TakeDamage(int Damage, DamageType type)
    {
        Effectiveness effect = Effectiveness.Neutral;
        int TrueDamage = Damage;
        foreach (var Vunerability in Vunerabilities)
        {
            if (type == Vunerability)
            {
                TrueDamage = TrueDamage * 2;
                effect = Effectiveness.Vunerable;
            }
        }
        foreach (var Resistance in Resistances)
        {
            if (type == Resistance)
            {
                TrueDamage = TrueDamage / 2;
                effect = Effectiveness.Resistant;
            }
        }
        foreach (var Immunity in Immunities)
        {
            if (type == Immunity)
            {
                TrueDamage = 0;
                effect = Effectiveness.Immune;
            }
        }
        AfterImageLevel = CurrentHealth;
        CurrentHealth -= TrueDamage;
        HealthText.text = CurrentHealth + " / " + MaxHealth;
        float cHealth = CurrentHealth;
        float mHealth = MaxHealth;
        HealthBar.fillAmount = cHealth / mHealth;
        if (CurrentHealth <= 0)
        {
            CurrentHealth = 0;
            HealthText.text = CurrentHealth + " / " + MaxHealth;
            this.gameObject.SetActive(false);
            DeathUI.SetActive(true);
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
    }

    private void Update()
    {
        float cHealth = CurrentHealth;
        float mHealth = MaxHealth;
        HealthBar.fillAmount = cHealth / mHealth;
        AfterImageLevel = Mathf.Lerp(AfterImageLevel, cHealth, AfterImageSpeed);
        HealthBarAfterImage.fillAmount = AfterImageLevel / mHealth;
        HealthText.text = CurrentHealth + " / " + MaxHealth;
    }

    public void RespawnPlayer()
    {
        transform.position = SpawnPoint.position;
        CurrentHealth = MaxHealth;
        this.gameObject.SetActive(true);
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        InputManager.horizontalInput = 0;
        InputManager.verticalInput = 0;
        transform.rotation = Quaternion.identity;
    }
}
