using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MakeExplosion : MonoBehaviour
{
    [SerializeField]
    private float ExplosionRadius;
    [SerializeField]
    private float ExplosionForce;
    [SerializeField]
    private float DestroyTime;


    void Start()
    {
        Explode();
        Destroy(this.gameObject, 5);
    }

    private void Explode()
    {
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, ExplosionRadius);
        foreach (var hitCollider in hitColliders)
        {
            if (hitCollider.GetComponent<EntityHealth>())
            {
                EntityHealth Helth = hitCollider.GetComponent<EntityHealth>();
                Vector3 Direction = hitCollider.transform.position - transform.position;
                Helth.DoKnockBack(Direction, ExplosionForce);
            }
        }
    }

    void Update()
    {
        
    }
}
