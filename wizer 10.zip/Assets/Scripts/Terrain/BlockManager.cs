using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockManager : MonoBehaviour
{
    public float UnityGridSize;

    Dictionary<Vector3Int, string> grid = new Dictionary<Vector3Int, string>();
    public Dictionary<Vector3Int, string> Grid { get { return grid; } }
    public Material BlockMaterial;

    // Object pooling
    private static Dictionary<string, Queue<GameObject>> BlockPool2 = new Dictionary<string, Queue<GameObject>>();
    public List<BlockType> blockTypes = new List<BlockType>();
    public int PoolSize = 50;
    public int MaxPoolSize = 1000;

    private void Awake()
    {
        InitialisePool();
    }

    private void InitialisePool()
    {
        foreach (var type in blockTypes)
        {
            Queue<GameObject> queue = new Queue<GameObject>();
            if (!BlockPool2.ContainsKey(type.BlockID))
            {
                BlockPool2.Add(type.BlockID, queue);
                for (int i = PoolSize; i > 0; i--)
                {
                    GameObject NewBlock = Instantiate(type.BlockPrefab, Vector3.zero, Quaternion.identity);
                    NewBlock.SetActive(false);
                    queue.Enqueue(NewBlock);
                }
            }
        }
        Debug.Log("The BlockPool has " + BlockPool2.Count + " types of blocks queued");
    }

    public GameObject GetPooledBlock(string blockID)
    {
        GameObject BlockObject = null;
        Queue<GameObject> queue;

        if (BlockPool2.TryGetValue(blockID, out queue))
        {
            if (queue.Count > 0)
            {
                BlockObject = queue.Dequeue();
            }
            else
            {
                BlockObject = Instantiate(blockTypes[0].BlockPrefab, Vector3.zero, Quaternion.identity);
            }
        }
        BlockObject.SetActive(true);
        return BlockObject;
    }

    public void RePoolBlock(GameObject BlockToQueue, string blocktype)
    {
        Queue<GameObject> queue;

        if (BlockPool2.TryGetValue(blocktype, out queue))
        {
            if (queue.Count < MaxPoolSize)
            {
                BlockToQueue.SetActive(false);
                queue.Enqueue(BlockToQueue);
            }
            else
            {
                Destroy(BlockToQueue);
            }
        }
    }

    public Vector3Int[] GetBlockSphere(Vector3 origin, float radius)
    {
        List<Vector3Int> blockPositions = new List<Vector3Int>();

        // Iterate through a bounding box around the origin
        for (int x = Mathf.FloorToInt((origin.x - radius) * 2); x <= Mathf.FloorToInt((origin.x + radius) * 2); x++)
        {
            for (int y = Mathf.FloorToInt((origin.y - radius) * 2); y <= Mathf.FloorToInt((origin.y + radius) * 2); y++)
            {
                for (int z = Mathf.FloorToInt((origin.z - radius) * 2); z <= Mathf.FloorToInt((origin.z + radius) * 2); z++)
                {
                    Vector3Int currentPosition = new Vector3Int(x, y, z);
                    // Calculate the distance from the origin
                    float distance = Vector3.Distance(origin, currentPosition / 2);

                    // If the distance is within the radius, add the block position
                    if (distance <= radius)
                    {
                        blockPositions.Add(currentPosition);
                        //Debug.Log(currentPosition);
                    }
                }
            }
        }

        return blockPositions.ToArray();
    }

    public GameObject InstantiateBlock(string blockid)
    {
        int BlockIndex = 0;
        foreach (var blockType in blockTypes)
        {
            if (blockType.BlockID == blockid)
            {
                BlockIndex = blockTypes.IndexOf(blockType);
            }
        }
        GameObject newBlock = Instantiate(blockTypes[BlockIndex].BlockPrefab);

        return newBlock;
    }
}
