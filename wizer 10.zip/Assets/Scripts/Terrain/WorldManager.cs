using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using UnityEditor;
using UnityEngine;

[System.Serializable]
public class BlockType
{
    public string BlockID;
    public GameObject BlockPrefab;
    public float Durability;

    public BlockType(string blockID, GameObject blockPrefab, float durability)
    {
        BlockID = blockID;
        BlockPrefab = blockPrefab;
        Durability = durability;
    }
}

[System.Serializable]
public struct block
{
    public Vector3Int Position;
    public string BlockId;

    public block(Vector3Int position, string blockid)
    {
        Position = position;
        BlockId = blockid;
    }
}

[ExecuteInEditMode]
public class WorldManager : MonoBehaviour
{
    [SerializeField]
    private BlockManager blockManager;
    [SerializeField]
    private List<StaticCube> AllBlocks;
    [SerializeField]
    private List<StaticCube> SortedBlocks;
    Dictionary<Vector3Int, Chunk> chunks = new Dictionary<Vector3Int, Chunk>();
    [SerializeField]
    private Vector3Int ChunkSize;

    private void Awake()
    {
        blockManager = FindFirstObjectByType<BlockManager>();
    }

    private void Start()
    {
        AllBlocks = FindObjectsByType<StaticCube>(FindObjectsSortMode.None).ToList();
        SortCubes();
    }

    public void SortCubesEditMode()
    {
        blockManager = FindFirstObjectByType<BlockManager>();
        AllBlocks = FindObjectsByType<StaticCube>(FindObjectsSortMode.None).ToList();
        
        foreach (var block in AllBlocks)
        {
            block.DisplayCoords();
        }
        SortCubes();
        foreach (var block in AllBlocks)
        {
            DestroyImmediate(block.gameObject);
        }
    }

    private void SortCubes()
    {
        foreach (KeyValuePair<Vector3Int, string> blockies in blockManager.Grid)
        {
            Vector3Int pos = blockies.Key;
            block cube = new block(blockies.Key, blockies.Value);

            Vector3Int chunkIndex = GetChunkIndex(pos);

            Chunk chunk;

            if (!chunks.TryGetValue(chunkIndex, out chunk))
            {
                GameObject chunky = new GameObject("Chunk " + chunkIndex.ToString(), typeof(Chunk));
                chunky.transform.position = chunkIndex * (ChunkSize/2);
                chunk = chunky.GetComponent<Chunk>();
                chunk.ChunkCoordinates = chunkIndex;
                chunks.Add(chunkIndex, chunk);
            }

            chunk.BlockList.Add(cube);
        }


    }

    public void MeshAllChunks()
    {
        Chunk[] AllChunks = FindObjectsByType<Chunk>(FindObjectsSortMode.None);
        foreach (var chunk in AllChunks)
        {
            if (!chunks.ContainsKey(chunk.ChunkCoordinates))
            {
                chunks.Add(chunk.ChunkCoordinates, chunk);
            }
        }
        foreach (KeyValuePair<Vector3Int, Chunk> chunkies in chunks)
        {
            chunkies.Value.CombineBlocks();
        }
    }

    public void UnMeshAllChunks()
    {
        Chunk[] AllChunks = FindObjectsByType<Chunk>(FindObjectsSortMode.None);
        foreach (var chunk in AllChunks)
        {
            if (!chunks.ContainsKey(chunk.ChunkCoordinates))
            {
                chunks.Add(chunk.ChunkCoordinates, chunk);
            }
        }
        foreach (KeyValuePair<Vector3Int, Chunk> chunkies in chunks)
        {
            chunkies.Value.UnCombineBlocks();
        }
    }

    public void ClearChunks()
    {
        chunks.Clear();
    }

    private Vector3Int GetChunkIndex(Vector3Int cubePosition)
    {
        return new Vector3Int(
            Mathf.FloorToInt(cubePosition.x / ChunkSize.x),
            Mathf.FloorToInt(cubePosition.y / ChunkSize.y),
            Mathf.FloorToInt(cubePosition.z / ChunkSize.z)
        );
    }
}


