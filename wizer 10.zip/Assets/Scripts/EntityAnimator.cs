using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EntityAnimator : MonoBehaviour
{
    [SerializeField]
    private Animator EntityAnim;
    [SerializeField]
    private EntityHealth EHealth;
    [SerializeField]
    private string KnockBackAnimBool;

    private void Start()
    {
        EHealth = GetComponent<EntityHealth>();
    }

    private void Update()
    {
        EntityAnim.SetBool(KnockBackAnimBool, EHealth.IsEnemyKnockedBack);
    }
}
