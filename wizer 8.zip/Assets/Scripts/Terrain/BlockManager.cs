using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockManager : MonoBehaviour
{
    public float UnityGridSize;

    Dictionary<Vector3Int, string> grid = new Dictionary<Vector3Int, string>();
    public Dictionary<Vector3Int, string> Grid { get { return grid; } }
    public Material BlockMaterial;

    // Object pooling
    public List<Queue<GameObject>> BlockPool = new List<Queue<GameObject>>();
    public List<BlockType> blockTypes = new List<BlockType>();
    public int PoolSize = 10;
    public int MaxPoolSize = 150;

    private void Awake()
    {
        //InitialisePool();
    }

    private void InitialisePool()
    {
        for (int i = 0; i < blockTypes.Count - 1; i++)
        {
            BlockPool.Add(new Queue<GameObject>());
            for (int j = 1; j < PoolSize; j++)
            {
                GameObject NewBlock = Instantiate(blockTypes[i].BlockPrefab, Vector3.zero, Quaternion.identity);
                BlockPool[i].Enqueue(NewBlock);
            }
        }
    }

    public GameObject GetPooledBlock(string blockID)
    {
        GameObject BlockObject = null;
        int BlockIndex = 0;
        foreach (var blockType in blockTypes)
        {
            if (blockType.BlockID == blockID)
            {
                BlockIndex = blockTypes.IndexOf(blockType);
            }
        }

        if (BlockPool[BlockIndex].Count > 0)
        {
            BlockObject = BlockPool[BlockIndex].Dequeue();
        }
        else
        {
            BlockObject = Instantiate(blockTypes[BlockIndex].BlockPrefab, Vector3.zero, Quaternion.identity);
        }
        return BlockObject;
    }

    public void RePoolBlock(GameObject BlockToQueue, BlockType blocktype)
    {
        int BlockIndex = 0;
        foreach (var blockType in blockTypes)
        {
            if (blockType.BlockID == blocktype.BlockID)
            {
                BlockIndex = blockTypes.IndexOf(blockType);
            }
        }
        if (BlockPool[BlockIndex].Count < MaxPoolSize)
        {
            BlockPool[BlockIndex].Enqueue(BlockToQueue);
        }
        else
        {
            Destroy(BlockToQueue);
        }
    }

    public GameObject InstantiateBlock(string blockid)
    {
        int BlockIndex = 0;
        foreach (var blockType in blockTypes)
        {
            if (blockType.BlockID == blockid)
            {
                BlockIndex = blockTypes.IndexOf(blockType);
            }
        }
        GameObject newBlock = Instantiate(blockTypes[BlockIndex].BlockPrefab);

        return newBlock;
    }
}
