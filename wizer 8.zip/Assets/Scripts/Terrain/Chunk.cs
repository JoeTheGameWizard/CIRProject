using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;
using UnityEditor;
using UnityEngine.UIElements;

[CustomEditor(typeof(Chunk))]
public class ChunkEditor : Editor
{
    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("Remesh Chunk"))
        {
            var chunkk = (Chunk)target;
            chunkk.CombineBlocks();
        }

        if (GUILayout.Button("Seperate Chunk"))
        {
            var chunkk = (Chunk)target;
            chunkk.UnCombineBlocks();
        }
        base.OnInspectorGUI();
    }
}

[ExecuteInEditMode]
public class Chunk : MonoBehaviour
{
    public List<block> BlockList = new List<block>();
    public List<GameObject> TempBlocks = new List<GameObject>();
    public Vector3Int ChunkCoordinates;

    public GameObject CurrentMeshObject;

    public List<Vector3> CurrentMeshVertices = new List<Vector3>();
    public List<int> CurrentMeshTriangles = new List<int>();
    public List<Vector2> CurrentMeshUVs = new List<Vector2>();
    private BlockManager Manager;

    public BlockType BlockType;

    private void Awake()
    {
        Manager = FindFirstObjectByType<BlockManager>();
    }

    private void Start()
    {
        if (Application.isPlaying)
        {
            Invoke(nameof(CombineBlocks), 3f);
        }
    }

    public void CombineBlocks()
    {
        if (CurrentMeshObject == null)
        {
            CurrentMeshObject = new GameObject("Chunk" + ChunkCoordinates + "Mesh",
        typeof(MeshFilter), typeof(MeshRenderer), typeof(MeshCollider), typeof(ChunkMesh));
            CurrentMeshObject.GetComponent<ChunkMesh>().ParentChunk = this;
        }

        Mesh BlockMesh = new Mesh();

        CurrentMeshVertices.Clear();
        CurrentMeshTriangles.Clear();
        CurrentMeshUVs.Clear();

        //remove duplicate entries
        BlockList = BlockList.GroupBy(x => x.Position).Select(g => g.First()).ToList();

        //delete entries if the corresponding cube is destroyed
        if (TempBlocks.Count > 0)
        {
            List<block> BlockListOverflow = new List<block>();
            List<GameObject> TempBlocksOverflow = new List<GameObject>();
            foreach (var tBlock in TempBlocks)
            {
                if (tBlock == null)
                {
                    TempBlocksOverflow.Add(tBlock);
                    BlockListOverflow.Add(BlockList[TempBlocks.IndexOf(tBlock)]);
                }
            }
            foreach (var blockB in TempBlocksOverflow)
            {
                TempBlocks.Remove(blockB);
            }
            foreach (var ListB in BlockListOverflow)
            {
                BlockList.Remove(ListB);
                Manager.Grid.Remove(ListB.Position);
            }
        }

        if (Application.isPlaying)
        {
            foreach (var DeBlock in TempBlocks)
            {
                Destroy(DeBlock);
            }
        }
        else
        {
            foreach (var DeBlock in TempBlocks)
            {
                DestroyImmediate(DeBlock);
            }
        }
        TempBlocks.Clear();

        //the following foreach loop generates the mesh for this chunk
        foreach (var block in BlockList)
        {   
            Vector3 Location = block.Position;
            //check above the cube; if there is a no cube above, create a face for the mesh
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(0, 1, 0)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;
                

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) + 
                    new Vector3(.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, -.25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 2);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 4);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                CurrentMeshUVs.Add(new Vector2(1, 1));
                CurrentMeshUVs.Add(new Vector2(1, 0));
                CurrentMeshUVs.Add(new Vector2(0, 0));
                CurrentMeshUVs.Add(new Vector2(0, 1));
            }
            //check below
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(0, -1, 0)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, -.25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 2);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 4);

                CurrentMeshUVs.Add(new Vector2(0, 1));
                CurrentMeshUVs.Add(new Vector2(0, 0));
                CurrentMeshUVs.Add(new Vector2(1, 0));
                CurrentMeshUVs.Add(new Vector2(1, 1));
            }
            //check infront
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(0, 0, 1)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, .25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 2);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 4);

                CurrentMeshUVs.Add(new Vector2(0, 1));
                CurrentMeshUVs.Add(new Vector2(1, 1));
                CurrentMeshUVs.Add(new Vector2(1, 0));
                CurrentMeshUVs.Add(new Vector2(0, 0));
            }
            //check behind
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(0, 0, -1)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, -.25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 2);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 4);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                CurrentMeshUVs.Add(new Vector2(1, 1));
                CurrentMeshUVs.Add(new Vector2(1, 0));
                CurrentMeshUVs.Add(new Vector2(0, 0));
                CurrentMeshUVs.Add(new Vector2(0, 1));
            }
            // check left
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(-1, 0, 0)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, -.25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 2);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 4);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                CurrentMeshUVs.Add(new Vector2(0, 1));
                CurrentMeshUVs.Add(new Vector2(1, 1));
                CurrentMeshUVs.Add(new Vector2(1, 0));
                CurrentMeshUVs.Add(new Vector2(0, 0));
            }
            //check right
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(1, 0, 0)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, -.25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 2);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 4);

                CurrentMeshUVs.Add(new Vector2(1, 1));
                CurrentMeshUVs.Add(new Vector2(1, 0));
                CurrentMeshUVs.Add(new Vector2(0, 0));
                CurrentMeshUVs.Add(new Vector2(0, 1));
            }
        }
        BlockMesh.vertices = CurrentMeshVertices.ToArray();
        BlockMesh.triangles = CurrentMeshTriangles.ToArray();
        BlockMesh.uv = CurrentMeshUVs.ToArray();
        BlockMesh.RecalculateNormals();

        CurrentMeshObject.SetActive(true);

        CurrentMeshObject.GetComponent<MeshRenderer>().material = Manager.BlockMaterial;
        CurrentMeshObject.GetComponent<MeshFilter>().mesh = BlockMesh;
        CurrentMeshObject.GetComponent<MeshCollider>().sharedMesh = null;
        CurrentMeshObject.GetComponent<MeshCollider>().sharedMesh = BlockMesh;
    }

    public void UnCombineBlocks()
    {
        //remove duplicate entries
        BlockList = BlockList.GroupBy(x => x.Position).Select(g => g.First()).ToList();

        CurrentMeshObject.SetActive(false);
        if (Application.isPlaying)
        {
            //in play mode we take cubes from the pool
            Invoke(nameof(CombineBlocks), 0.5f);
        }
        else
        {
            //in edit mode we instantiate new cubes to be used during editing
            foreach (var blockA in BlockList)
            {
                GameObject newwBlock = Manager.InstantiateBlock(blockA.BlockId);
                Vector3 Location = blockA.Position;
                newwBlock.transform.position = Location / 2;
                TempBlocks.Add(newwBlock);
            }
        }
    }
}
