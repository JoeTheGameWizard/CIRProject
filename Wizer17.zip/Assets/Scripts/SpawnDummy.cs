using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnDummy : MonoBehaviour
{
    [SerializeField]
    private GameObject Dummy;
    [SerializeField]
    private GameObject DummySpawnEffects;
    [SerializeField]
    private float DummyCheckTime;

    private GameObject CurrentDummy;

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating(nameof(CreateDummy), 0f, DummyCheckTime);
    }

    private void CreateDummy()
    {
        if (CurrentDummy == null)
        {
            CurrentDummy = Instantiate(Dummy, transform.position, Quaternion.identity);
            Instantiate(DummySpawnEffects, transform.position, Quaternion.identity);
        }
    }
}
