using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;
using UnityEditor;
using UnityEngine.UIElements;
using UnityEditor.Overlays;
using UnityEditor.PackageManager;

[ExecuteInEditMode]
public class Chunk : MonoBehaviour
{
    public List<block> BlockList = new List<block>();
    public List<GameObject> TempBlocks = new List<GameObject>();
    public Vector3Int ChunkCoordinates;

    public GameObject CurrentMeshObject;

    public List<Vector3> CurrentMeshVertices = new List<Vector3>();
    public List<int> CurrentMeshTriangles = new List<int>();
    public List<Vector2> CurrentMeshUVs = new List<Vector2>();
    private BlockManager Manager;
    private WorldManager worldManager;

    [SerializeField]
    private List<block> BlocksToSpawn = new List<block>();
    private List<Vector3> BlockVelocities = new List<Vector3>();
    public BlockType BlockType;

    private Vector2Int TextureSize;
    private Texture blockTexture;

    private void Awake()
    {
        Manager = FindFirstObjectByType<BlockManager>();
        worldManager = FindFirstObjectByType<WorldManager>();
    }

    private void Start()
    {
        TextureSize = Manager.BlockTextureSize;
        blockTexture = Manager.BlockTexture;
        if (Application.isPlaying)
        {
            Invoke(nameof(CombineBlocks), 3f);
        }
    }

    //destroy blocks function, this is called from other scripts when they want to break blocks in this chunk
    public void DestroyBlocks(List<Vector3Int> BlocksToDestroy, float[] Damage, List<Vector3> blockVelo)
    {
        BlockVelocities.Clear();
        foreach (var blockPos in BlocksToDestroy)
        {
            int blockIndex = BlockList.FindIndex(b => b.Position == blockPos);
            if (blockIndex >= 0)
            {
                block block = BlockList[blockIndex];
                BlockType type;
                if (Manager.blockTypesDic.TryGetValue(block.BlockId, out type))
                {
                    if (Damage[BlocksToDestroy.IndexOf(blockPos)] >= type.Durability)
                    {
                        BlockVelocities = blockVelo;
                        BlocksToSpawn.Add(new block(blockPos, BlockList[blockIndex].BlockId));
                        BlockList.RemoveAt(blockIndex);
                        Manager.Grid.Remove(blockPos);
                    }
                }
                else
                {
                    Debug.LogError("This block is not listed as a blocktype!");
                }

            }
        }
        UpdateMesh();
        UpdateNeighbouringChunks();
        Invoke(nameof(SpawnBlocks), 0.01f);
    }

    private void SpawnBlocks()
    {
        foreach (var blocks in BlocksToSpawn)
        {
            int blockIndex = BlocksToSpawn.IndexOf(blocks);
            GameObject PhysBlock = Manager.GetPooledBlock(blocks.BlockId);
            Vector3 position = blocks.Position;
            PhysBlock.transform.position = position / 2f;
            PhysBlock.GetComponent<ActiveCube>().FlingSelf(BlockVelocities[blockIndex]);
        }
        BlocksToSpawn.Clear();
    }

    //we check adjacent chunks and update them, to prevent seeing the inside of chunks when destroying the edge of a chunk
    public void UpdateNeighbouringChunks()
    {
        Chunk NeighbourChunk;
        if (worldManager.chunks.TryGetValue(ChunkCoordinates + new Vector3Int(1, 0, 0), out NeighbourChunk))
        {
            NeighbourChunk.UpdateMesh();
        }
        if (worldManager.chunks.TryGetValue(ChunkCoordinates + new Vector3Int(-1, 0, 0), out NeighbourChunk))
        {
            NeighbourChunk.UpdateMesh();
        }
        if (worldManager.chunks.TryGetValue(ChunkCoordinates + new Vector3Int(0, 1, 0), out NeighbourChunk))
        {
            NeighbourChunk.UpdateMesh();
        }
        if (worldManager.chunks.TryGetValue(ChunkCoordinates + new Vector3Int(0, -1, 0), out NeighbourChunk))
        {
            NeighbourChunk.UpdateMesh();
        }
        if (worldManager.chunks.TryGetValue(ChunkCoordinates + new Vector3Int(0, 0, 1), out NeighbourChunk))
        {
            NeighbourChunk.UpdateMesh();
        }
        if (worldManager.chunks.TryGetValue(ChunkCoordinates + new Vector3Int(0, 0, -1), out NeighbourChunk))
        {
            NeighbourChunk.UpdateMesh();
        }
    }

    public void UpdateMesh()
    {
        TextureSize = Manager.BlockTextureSize;
        blockTexture = Manager.BlockTexture;

        if (CurrentMeshObject == null)
        {
            CurrentMeshObject = new GameObject("Chunk" + ChunkCoordinates + "Mesh",
        typeof(MeshFilter), typeof(MeshRenderer), typeof(MeshCollider), typeof(ChunkMesh));
            CurrentMeshObject.GetComponent<ChunkMesh>().ParentChunk = this;
        }

        Mesh BlockMesh = new Mesh();

        CurrentMeshVertices.Clear();
        CurrentMeshTriangles.Clear();
        CurrentMeshUVs.Clear();

        //remove duplicate entries
        BlockList = BlockList.GroupBy(x => x.Position).Select(g => g.First()).ToList();

        Vector2 textureScale = Manager.BlockTextureSize / new Vector2(Manager.BlockTexture.width, Manager.BlockTexture.height);

        //the following foreach loop generates the mesh for this chunk
        foreach (var block in BlockList)
        {
            Vector3 Location = block.Position;
            //check above the cube; if there is a no cube above, create a face for the mesh
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(0, 1, 0)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, -.25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 2);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 4);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                BlockType type;
                if (Manager.blockTypesDic.TryGetValue(block.BlockId, out type))
                {
                    Vector2 textureLoc = type.BlockTopTexture / new Vector2(blockTexture.width, blockTexture.height);

                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y + textureScale.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y + textureScale.y));
                }
                else
                {
                    Debug.LogError("block type was not found!");
                }
            }
            //check below
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(0, -1, 0)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, -.25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 2);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 4);

                BlockType type;
                if (Manager.blockTypesDic.TryGetValue(block.BlockId, out type))
                {
                    Vector2 textureLoc = type.BlockBottomTexture / new Vector2(blockTexture.width, blockTexture.height);

                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y + textureScale.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y + textureScale.y));
                }
                else
                {
                    Debug.LogError("block type was not found!");
                }
            }
            //check infront
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(0, 0, 1)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, .25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 2);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 4);

                BlockType type;
                if (Manager.blockTypesDic.TryGetValue(block.BlockId, out type))
                {
                    Vector2 textureLoc = type.BlockNorthTexture / new Vector2(blockTexture.width, blockTexture.height);

                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y + textureScale.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y + textureScale.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y));
                }
                else
                {
                    Debug.LogError("block type was not found!");
                }
            }
            //check behind
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(0, 0, -1)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, -.25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 2);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 4);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                BlockType type;
                if (Manager.blockTypesDic.TryGetValue(block.BlockId, out type))
                {
                    Vector2 textureLoc = type.BlockSouthTexture / new Vector2(blockTexture.width, blockTexture.height);

                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y + textureScale.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y + textureScale.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y));
                }
                else
                {
                    Debug.LogError("block type was not found!");
                }
            }
            // check left
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(-1, 0, 0)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, -.25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 2);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 4);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                BlockType type;
                if (Manager.blockTypesDic.TryGetValue(block.BlockId, out type))
                {
                    Vector2 textureLoc = type.BlockWestTexture / new Vector2(blockTexture.width, blockTexture.height);

                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y + textureScale.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y + textureScale.y));
                }
                else
                {
                    Debug.LogError("block type was not found!");
                }
            }
            //check right
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(1, 0, 0)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, -.25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 2);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 4);

                BlockType type;
                if (Manager.blockTypesDic.TryGetValue(block.BlockId, out type))
                {
                    Vector2 textureLoc = type.BlockEastTexture / new Vector2(blockTexture.width, blockTexture.height);

                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y + textureScale.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y + textureScale.y));
                }
                else
                {
                    Debug.LogError("block type was not found!");
                }
            }
        }
        BlockMesh.vertices = CurrentMeshVertices.ToArray();
        BlockMesh.triangles = CurrentMeshTriangles.ToArray();
        BlockMesh.uv = CurrentMeshUVs.ToArray();
        BlockMesh.RecalculateNormals();

        CurrentMeshObject.SetActive(true);

        CurrentMeshObject.GetComponent<MeshFilter>().mesh = BlockMesh;
        CurrentMeshObject.GetComponent<MeshCollider>().sharedMesh = null;
        CurrentMeshObject.GetComponent<MeshCollider>().sharedMesh = BlockMesh;
    }

    //the use of this function in playmode is deprecated, use UpdateMesh() instead.
    public void CombineBlocks()
    {
        TextureSize = Manager.BlockTextureSize;
        blockTexture = Manager.BlockTexture;

        if (CurrentMeshObject == null)
        {
            CurrentMeshObject = new GameObject("Chunk" + ChunkCoordinates + "Mesh",
        typeof(MeshFilter), typeof(MeshRenderer), typeof(MeshCollider), typeof(ChunkMesh));
            CurrentMeshObject.GetComponent<ChunkMesh>().ParentChunk = this;
        }

        Mesh BlockMesh = new Mesh();

        CurrentMeshVertices.Clear();
        CurrentMeshTriangles.Clear();
        CurrentMeshUVs.Clear();

        //remove duplicate entries
        BlockList = BlockList.GroupBy(x => x.Position).Select(g => g.First()).ToList();

        //delete entries if the corresponding cube is destroyed
        if (TempBlocks.Count > 0)
        {
            List<block> BlockListOverflow = new List<block>();
            List<GameObject> TempBlocksOverflow = new List<GameObject>();
            foreach (var tBlock in TempBlocks)
            {
                if (tBlock == null)
                {
                    TempBlocksOverflow.Add(tBlock);
                    BlockListOverflow.Add(BlockList[TempBlocks.IndexOf(tBlock)]);
                }
            }
            foreach (var blockB in TempBlocksOverflow)
            {
                TempBlocks.Remove(blockB);
            }
            foreach (var ListB in BlockListOverflow)
            {
                BlockList.Remove(ListB);
                Manager.Grid.Remove(ListB.Position);
            }
        }

        //Remove cubes before generating mesh
        if (!Application.isPlaying)
        {
            foreach (var DeBlock in TempBlocks)
            {
                DestroyImmediate(DeBlock);
            }
        }
        TempBlocks.Clear();

        Vector2 textureScale = Manager.BlockTextureSize / new Vector2(Manager.BlockTexture.width, Manager.BlockTexture.height);

        //the following foreach loop generates the mesh for this chunk
        foreach (var block in BlockList)
        {   
            Vector3 Location = block.Position;
            //check above the cube; if there is a no cube above, create a face for the mesh
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(0, 1, 0)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, -.25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 2);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 4);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                BlockType type;
                if (Manager.blockTypesDic.TryGetValue(block.BlockId, out type))
                {
                    Vector2 textureLoc = type.BlockTopTexture / new Vector2(blockTexture.width, blockTexture.height);

                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y + textureScale.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y + textureScale.y));
                }
                else
                {
                    Debug.LogError("block type was not found!");
                }
            }
            //check below
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(0, -1, 0)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, -.25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 2);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 4);

                BlockType type;
                if (Manager.blockTypesDic.TryGetValue(block.BlockId, out type))
                {
                    Vector2 textureLoc = type.BlockBottomTexture / new Vector2(blockTexture.width, blockTexture.height);

                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y + textureScale.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y + textureScale.y));
                }
                else
                {
                    Debug.LogError("block type was not found!");
                }
            }
            //check infront
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(0, 0, 1)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, .25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 2);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 4);

                BlockType type;
                if (Manager.blockTypesDic.TryGetValue(block.BlockId, out type))
                {
                    Vector2 textureLoc = type.BlockNorthTexture / new Vector2(blockTexture.width, blockTexture.height);

                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y + textureScale.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y + textureScale.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y));
                }
                else
                {
                    Debug.LogError("block type was not found!");
                }
            }
            //check behind
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(0, 0, -1)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, -.25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 2);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 4);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                BlockType type;
                if (Manager.blockTypesDic.TryGetValue(block.BlockId, out type))
                {
                    Vector2 textureLoc = type.BlockSouthTexture / new Vector2(blockTexture.width, blockTexture.height);

                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y + textureScale.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y + textureScale.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y));
                }
                else
                {
                    Debug.LogError("block type was not found!");
                }
            }
            // check left
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(-1, 0, 0)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, -.25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(-.25f, .25f, -.25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 2);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 4);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                BlockType type;
                if (Manager.blockTypesDic.TryGetValue(block.BlockId, out type))
                {
                    Vector2 textureLoc = type.BlockWestTexture / new Vector2(blockTexture.width, blockTexture.height);

                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y + textureScale.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y + textureScale.y));
                }
                else
                {
                    Debug.LogError("block type was not found!");
                }
            }
            //check right
            if (!Manager.Grid.ContainsKey(block.Position + new Vector3Int(1, 0, 0)))
            {
                int VerticesStart = CurrentMeshVertices.Count - 1;


                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, .25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, -.25f, -.25f));

                CurrentMeshVertices.Add(new Vector3(Location.x / 2, Location.y / 2, Location.z / 2) +
                    new Vector3(.25f, .25f, -.25f));

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 2);
                CurrentMeshTriangles.Add(VerticesStart + 3);

                CurrentMeshTriangles.Add(VerticesStart + 1);
                CurrentMeshTriangles.Add(VerticesStart + 3);
                CurrentMeshTriangles.Add(VerticesStart + 4);

                BlockType type;
                if (Manager.blockTypesDic.TryGetValue(block.BlockId, out type))
                {
                    Vector2 textureLoc = type.BlockEastTexture / new Vector2(blockTexture.width, blockTexture.height);

                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y + textureScale.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x + textureScale.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y));
                    CurrentMeshUVs.Add(new Vector2(textureLoc.x, textureLoc.y + textureScale.y));
                }
                else
                {
                    Debug.LogError("block type was not found!");
                }
            }
        }
        BlockMesh.vertices = CurrentMeshVertices.ToArray();
        BlockMesh.triangles = CurrentMeshTriangles.ToArray();
        BlockMesh.uv = CurrentMeshUVs.ToArray();
        BlockMesh.RecalculateNormals();

        CurrentMeshObject.SetActive(true);

        CurrentMeshObject.GetComponent<MeshRenderer>().material = Manager.BlockMaterial;
        CurrentMeshObject.GetComponent<MeshFilter>().mesh = BlockMesh;
        CurrentMeshObject.GetComponent<MeshCollider>().sharedMesh = null;
        CurrentMeshObject.GetComponent<MeshCollider>().sharedMesh = BlockMesh;
    }

    //like Combineblocks() this function is only to be used in edit mode via the button in the inspector, DestroyBlocks() is the new alternative
    public void UnCombineBlocks()
    {
        //remove duplicate entries
        BlockList = BlockList.GroupBy(x => x.Position).Select(g => g.First()).ToList();

        CurrentMeshObject.SetActive(false);
        if (!Application.isPlaying)
        {
            //in edit mode we instantiate new cubes to be used during editing
            foreach (var blockA in BlockList)
            {
                GameObject newwBlock = Manager.InstantiateBlock(blockA.BlockId);
                Vector3 Location = blockA.Position;
                newwBlock.transform.position = Location / 2;
                newwBlock.transform.parent = this.gameObject.transform;
                TempBlocks.Add(newwBlock);
            }
        }
    }
}
