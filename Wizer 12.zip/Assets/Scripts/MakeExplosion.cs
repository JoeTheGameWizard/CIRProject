using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

public class MakeExplosion : MonoBehaviour
{
    [SerializeField]
    private float ExplosionRadius;
    [SerializeField]
    private float ExplosionForce;
    [SerializeField]
    private float EnvironmentDamage;
    [SerializeField]
    private float EntityDamage;
    [SerializeField]
    private float DestroyTime;
    [SerializeField]
    private AnimationCurve ExplosionFalloff;

    private BlockManager blockManager;

    void Start()
    {
        blockManager = FindFirstObjectByType<BlockManager>();
        Explode();
        Destroy(this.gameObject, DestroyTime);
    }

    private void Explode()
    {
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, ExplosionRadius);
        foreach (var hitCollider in hitColliders)
        {
            if (hitCollider.GetComponent<ChunkMesh>())
            {
                Chunk chunk = hitCollider.GetComponent<ChunkMesh>().ParentChunk;
                List<Vector3Int> blocksToDestroy = blockManager.GetBlockSphere(transform.position, ExplosionRadius).ToList();
                List <float> Damage = new List<float>();
                List<Vector3> blockVelocity = new List<Vector3>();
                foreach (var blockToDestroy in blocksToDestroy)
                {
                    Vector3 blockPosition = blockToDestroy;
                    blockPosition = blockPosition / 2f; // Possible issue here
                    Debug.Log("Block Position: " + blockPosition); // Debugging
                    Debug.Log("Explosion Position: " + transform.position); // Debugging
                    Vector3 delta = ((blockPosition) - transform.position);
                    Debug.Log("Delta: " + delta); // Debugging
                    Damage.Add((ExplosionFalloff.Evaluate(delta.magnitude / ExplosionRadius)) * EnvironmentDamage);
                    blockVelocity.Add(delta.normalized * ExplosionForce);
                    Debug.DrawLine(transform.position, transform.position + delta, Color.red, 1f); // Visualize the delta vector
                }
                chunk.DestroyBlocks(blocksToDestroy, Damage.ToArray(), blockVelocity);
                Debug.Log("Destroy blocks?");
            }
            if (hitCollider.GetComponent<EntityHealth>())
            {
                EntityHealth Helth = hitCollider.GetComponent<EntityHealth>();
                Vector3 Direction = hitCollider.transform.position - transform.position;
                Helth.DoKnockBack(Direction, ExplosionForce);
            }
            if (hitCollider.GetComponent<ActiveCube>())
            {
                ActiveCube activeCube = hitCollider.GetComponent<ActiveCube>();
                Vector3 Direction = hitCollider.transform.position - transform.position;
                activeCube.FlingSelf(Direction.normalized * ExplosionForce);
            }
        }
    }

    void Update()
    {
        
    }
}
