using System.Collections;
using System.Collections.Generic;

using UnityEditor.Rendering;
using UnityEngine;

public class CameraManager : MonoBehaviour
{
    InputManager inputManager;

    [Header("Obj refs to camera + pivot")]
    [SerializeField]
    private Transform cameraPivot;//object ref to the camera pivot
    [SerializeField]
    private Transform cameraTransform;// object ref to the actual camera

    [Header("Speeds for various things. pivot is up/down")]
    [SerializeField]
    private float FollowSpeed;
    [SerializeField]
    private float cameraLookSpeed = 2f;
    [SerializeField]
    private float cameraPivotSpeed = 2f;

    [Header("Settings for vertical movement and collision")]
    [SerializeField]
    private float minPivotAngle = -35f;
    [SerializeField]
    private float maxPivotAngle = 35f;
    [SerializeField]
    private float cameraCollisionRadius = 0.2f;
    [SerializeField]
    private float minCollisionOffset = 0.2f; //how much the camera jumps off of objects
    [SerializeField]
    private LayerMask collisionLayers;

    private Vector3 cameraFollowVelocity = Vector3.zero;
    private Transform targetTransform;
    private float defaultPosition;
    private Vector3 cameraVectorPosition;


    public float lookAngle;//up and down 
    public float pivotAngle;//left and right

    private void Awake()
    {
        inputManager = FindFirstObjectByType<InputManager>();
        targetTransform = FindFirstObjectByType<PlayerManager>().transform;
        defaultPosition = cameraTransform.localPosition.z;
    }
    
    public void HandleAllCameraMovement()
    {
        FollowTarget();
        RotateCamera();
        HandleCameraCollision();
    }

    private void FollowTarget()
    {
        Vector3 targetPosition = Vector3.SmoothDamp
            (transform.position, targetTransform.position, ref cameraFollowVelocity, FollowSpeed);
        transform.position = targetPosition;
    }

    private void RotateCamera()
    {
        Vector3 rotation;
        Quaternion targetRotation;

        lookAngle = lookAngle + (inputManager.cameraInputX * cameraLookSpeed);
        pivotAngle = pivotAngle + (inputManager.cameraInputY * cameraPivotSpeed);
        pivotAngle = Mathf.Clamp(pivotAngle, minPivotAngle, maxPivotAngle);

        rotation = Vector3.zero;
        rotation.y = lookAngle;
        targetRotation = Quaternion.Euler(rotation);
        transform.rotation = targetRotation;

        rotation = Vector3.zero;
        rotation.x = pivotAngle;
        targetRotation = Quaternion.Euler(rotation);
        cameraPivot.localRotation = targetRotation;
    }

    private void HandleCameraCollision()
    {
        float targetPosition = defaultPosition;
        RaycastHit hit;
        Vector3 direction = cameraTransform.position - cameraPivot.position;
        direction.Normalize();

        if (Physics.SphereCast(cameraPivot.transform.position, cameraCollisionRadius, direction, out hit, Mathf.Abs(targetPosition), collisionLayers))
        {
            float distance = Vector3.Distance(cameraPivot.position, hit.point);
            targetPosition =- (distance - cameraCollisionRadius);
        }

        if (Mathf.Abs(targetPosition) < minCollisionOffset)
        {
            targetPosition = targetPosition - minCollisionOffset;
        }

        cameraVectorPosition.z = Mathf.Lerp(cameraTransform.localPosition.z, targetPosition, 0.2f);
        cameraTransform.localPosition = cameraVectorPosition;
    }
}
