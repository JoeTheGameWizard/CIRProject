using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerManager : MonoBehaviour
{
    InputManager inputManager;
    CameraManager camManager;
    PlayerLocomotion playerLoco;

    private void Awake()
    {
        camManager = FindFirstObjectByType<CameraManager>();
        inputManager = GetComponent<InputManager>();
        playerLoco = GetComponent<PlayerLocomotion>();
    }

    private void Update()
    {
        inputManager.HandleAllInputs();
    }

    private void FixedUpdate()
    {
        playerLoco.HandleAllMovement();
    }

    private void LateUpdate()
    {
        camManager.HandleAllCameraMovement();
    }
}
