using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerLocomotion : MonoBehaviour
{
    public bool IsSprinting;

    [SerializeField]
    private Transform cameraObject;
    [SerializeField]
    private Rigidbody PlayerRB;
    [SerializeField]
    private float WalkingSpeed = 2.5f;
    [SerializeField]
    private float SprintingSpeed = 7f;
    [SerializeField]
    private float RotationSpeed = 15f;

    private Vector3 MoveDirection;
    private InputManager inputManager;

    private void Awake()
    {
        inputManager = GetComponent<InputManager>();
        PlayerRB = GetComponent<Rigidbody>();
        cameraObject = Camera.main.transform;
    }

    public void HandleAllMovement()
    {
        HandleMovement();
        HandleRotation();
    }

    private void HandleMovement()
    {
        MoveDirection = cameraObject.forward * inputManager.verticalInput;
        MoveDirection = MoveDirection + cameraObject.right * inputManager.horizontalInput;
        MoveDirection.Normalize();
        MoveDirection.y = 0;
        if (IsSprinting)
        {
            MoveDirection = MoveDirection * SprintingSpeed;
        }
        else
        {
            MoveDirection = MoveDirection * WalkingSpeed;
        }

        Vector3 movementVelocity = MoveDirection;
        PlayerRB.velocity = movementVelocity;
    }

    private void HandleRotation()
    {
        Vector3 TargetDirection = Vector3.zero;

        TargetDirection = cameraObject.forward * inputManager.verticalInput;
        TargetDirection = TargetDirection + cameraObject.right * inputManager.horizontalInput;
        TargetDirection.Normalize();
        TargetDirection.y = 0;

        if (TargetDirection == Vector3.zero)
            TargetDirection = transform.forward;

        Quaternion TargetRotation = Quaternion.LookRotation(TargetDirection);
        Quaternion PlayerRotation = Quaternion.Slerp(transform.rotation, TargetRotation, RotationSpeed * Time.deltaTime);
        transform.rotation = PlayerRotation;
    }
}
