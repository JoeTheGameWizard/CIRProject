using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManagePlayerAnimations : MonoBehaviour
{
    [SerializeField]
    private Animator PlayerAnim;
    [SerializeField]
    private InputManager InputManager;

    private void Awake()
    {
        PlayerAnim = GetComponentInChildren<Animator>();
        InputManager = GetComponentInChildren<InputManager>();
    }
    private void Update()
    {
        if (InputManager.verticalInput != 0 || InputManager.horizontalInput != 0)
        {
            PlayerAnim.SetBool("IsMoving", true);
        }
        else
        {
            PlayerAnim.SetBool("IsMoving", false);
        }

        PlayerAnim.SetBool("IsSprinting", InputManager.SprintInput);
    }
}
