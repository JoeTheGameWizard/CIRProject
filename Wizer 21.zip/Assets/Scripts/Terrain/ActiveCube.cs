using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActiveCube : MonoBehaviour
{
    [SerializeField]
    Rigidbody rb;
    [SerializeField]
    private float Durability;
    public string blockID;

    private BlockManager manager;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
        manager = FindFirstObjectByType<BlockManager>();
    }

    public void DamageCube(float Damage)
    {
        if (Damage > Durability)
        {
            manager.RePoolBlock(this.gameObject, blockID);
        }
    }

    public void FlingSelf(Vector3 Direction)
    {
        rb.velocity = Direction;
    }
}
