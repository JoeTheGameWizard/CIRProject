using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EntityHealth : MonoBehaviour
{
    public bool IsEnemyKnockedBack = false;
    [SerializeField]
    private float KnockbackRotationSpeed;
    
    [SerializeField]
    private Transform Feet;
    [SerializeField]
    private LayerMask GroundLayers;
    public bool IsGrounded;
    private EntityAnimator EnAnim;
    private Rigidbody EntityRB;

    private void Awake()
    {
        EnAnim = GetComponent<EntityAnimator>();
        EntityRB = GetComponent<Rigidbody>();
    }

    public void DoKnockBack(Vector3 Direction, float Magnitude)
    {
        Direction.Normalize();
        transform.position = transform.position + new Vector3(0, 0.08f, 0);
        EntityRB.velocity = Direction * Magnitude;
        IsEnemyKnockedBack = true;
    }

    private void Update()
    {
        IsGrounded = Physics.CheckSphere(Feet.position, 0.1f, GroundLayers);

        if (IsEnemyKnockedBack)
        {
            Vector3 RotTarget = EntityRB.velocity;
            RotTarget.y = 0;
            Quaternion TargetRotation = Quaternion.LookRotation(RotTarget);
            Quaternion EntRotation = Quaternion.Slerp(transform.rotation, TargetRotation, KnockbackRotationSpeed * Time.deltaTime);
            transform.rotation = EntRotation;
        }

        if (IsGrounded)
        {
            if (EntityRB.velocity.magnitude < 0.2f)
            {
                IsEnemyKnockedBack = false;
            }
        }
    }
}
