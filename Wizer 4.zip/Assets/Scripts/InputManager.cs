using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputManager : MonoBehaviour
{
    [SerializeField]
    private PlayerControls playercontrols;
    PlayerLocomotion locomotion;
    PlayerMagic magic;

    [SerializeField]
    private Vector2 MovementInput;
    public Vector2 cameraInput;

    public float cameraInputX;
    public float cameraInputY;

    public float verticalInput;
    public float horizontalInput;

    public bool SprintInput;
    public bool JumpInput;

    public bool FloatInput;
    public bool CastInput;

    private void OnEnable()
    {
        if (playercontrols == null)
        {
            playercontrols = new PlayerControls();

            playercontrols.PlayerMovement.Movement.performed += i => MovementInput = i.ReadValue<Vector2>();
            playercontrols.PlayerMovement.Camera.performed += i => cameraInput = i.ReadValue<Vector2>();

            playercontrols.PlayerActions.Sprint.performed += i => SprintInput = true;
            playercontrols.PlayerActions.Sprint.canceled += i => SprintInput = false;

            playercontrols.PlayerSpellCasting.Float.performed += i => FloatInput = true;
            playercontrols.PlayerSpellCasting.Float.canceled += i => FloatInput = false;

            playercontrols.PlayerSpellCasting.CastSpell.performed += i => CastInput = true;

            playercontrols.PlayerActions.Jump.performed += i => JumpInput = true;
        }

        playercontrols.Enable();
    }

    private void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    private void Awake()
    {
        locomotion = GetComponent<PlayerLocomotion>();
        magic = GetComponent<PlayerMagic>();
    }

    private void OnDisable()
    {
        playercontrols.Disable();
    }

    public void HandleAllInputs()
    {
        HandleMovementInput();
        HandleSprintInput();
        HandleJumpInput();
        HandleCastingInput();
    }

    private void HandleMovementInput()
    {
        verticalInput = MovementInput.y;
        horizontalInput = MovementInput.x;

        cameraInputX = cameraInput.x;
        cameraInputY = cameraInput.y;
    }

    private void HandleSprintInput()
    {
        locomotion.IsSprinting = SprintInput;
    }

    private void HandleJumpInput()
    {
        if (JumpInput)
        {
            JumpInput = false;
            locomotion.HandleJumping();
        }
    }

    private void HandleCastingInput()
    {
        if (CastInput)
        {
            CastInput = false;
            magic.CastSpell();
        }
    }
}
