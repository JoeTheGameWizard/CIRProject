using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManagePlayerAnimations : MonoBehaviour
{
    [SerializeField]
    private Animator PlayerAnim;
    [SerializeField]
    private InputManager InputManager;

    private PlayerLocomotion loco;
    private Rigidbody rb;

    private void Awake()
    {
        PlayerAnim = GetComponentInChildren<Animator>();
        InputManager = GetComponentInChildren<InputManager>();
        loco = GetComponent<PlayerLocomotion>();
        rb = GetComponent<Rigidbody>();
    }
    private void Update()
    {
        if (InputManager.verticalInput != 0 || InputManager.horizontalInput != 0)
        {
            PlayerAnim.SetBool("IsMoving", true);
        }
        else
        {
            PlayerAnim.SetBool("IsMoving", false);
        }

        PlayerAnim.SetBool("IsSprinting", InputManager.SprintInput);
        PlayerAnim.SetBool("IsGrounded", loco.IsGrounded);
        if (!loco.IsGrounded && !loco.IsJumping)
        {
            if (loco.LongFallVelocity > rb.velocity.y)
            {
                PlayerAnim.SetBool("IsLongFall", true);
            }
            else
            {
                PlayerAnim.SetBool("IsLongFall", false);
            }
        }
        loco.IsLongFall = PlayerAnim.GetBool("IsLongFall");
    }

    public void PlayTargetAnimation(string targetAnimation, bool isInteracting)
    {
        PlayerAnim.SetBool("IsInteracting", isInteracting);
        PlayerAnim.CrossFade(targetAnimation, 0.1f);
    }
}
