using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EntityHealth : MonoBehaviour
{
    public bool IsEnemyKnockedBack = false;
    [SerializeField]
    private float KnockbackRotationSpeed;
    
    [SerializeField]
    private Transform Feet;
    [SerializeField]
    private LayerMask GroundLayers;
    [SerializeField]
    private float KnockBackResistance = 1f;

    [Space(15)]

    [SerializeField]
    private int MaximumHealth;
    [SerializeField]
    private int CurrentHealth;
    [SerializeField]
    private DamageType[] Vunerabilities;
    [SerializeField]
    private DamageType[] Resistances;
    [SerializeField]
    private DamageType[] Immunities;
    [SerializeField]
    private GameObject HealthSprite;
    private float HealthSpriteInitialScale;
    public bool IsGrounded;
    private EntityAnimator EnAnim;
    private Rigidbody EntityRB;
    private HealthManager HealthMana;

    private void Awake()
    {
        EnAnim = GetComponent<EntityAnimator>();
        EntityRB = GetComponent<Rigidbody>();
        HealthMana = FindFirstObjectByType<HealthManager>();
        CurrentHealth = MaximumHealth;
        HealthSpriteInitialScale = HealthSprite.transform.localScale.x;
    }

    public void DoKnockBack(Vector3 Direction, float Magnitude)
    {
        if (Magnitude > KnockBackResistance)
        {
            Direction.Normalize();
            transform.position = transform.position + new Vector3(0, 0.08f, 0);
            EntityRB.velocity = Direction * Magnitude;
            IsEnemyKnockedBack = true;
        }
    }

    public void DoDamage(int Damage, DamageType type)
    {
        int TrueDamage = Damage;
        foreach (var Vunerability in Vunerabilities)
        {
            if (type == Vunerability)
            {
                TrueDamage = TrueDamage * 2;
            }
        }
        foreach (var Resistance in Resistances)
        {
            if (type == Resistance)
            {
                TrueDamage = TrueDamage / 2;
            }
        }
        foreach (var Immunity in Immunities)
        {
            if (type == Immunity)
            {
                TrueDamage = 0;
            }
        }
        CurrentHealth -= TrueDamage;
        HealthMana.DoDamageNumbers(TrueDamage, type, transform.position);

    }

    private void Update()
    {
        float currenthelth = CurrentHealth;
        float maxhelt = MaximumHealth;
        HealthSprite.transform.localScale = 
            new Vector3((currenthelth / maxhelt),
         HealthSprite.transform.localScale.y, HealthSprite.transform.localScale.z);
        IsGrounded = Physics.CheckSphere(Feet.position, 0.1f, GroundLayers);

        if (IsEnemyKnockedBack)
        {
            Vector3 RotTarget = EntityRB.velocity;
            RotTarget.y = 0;
            Quaternion TargetRotation = Quaternion.LookRotation(RotTarget);
            Quaternion EntRotation = Quaternion.Slerp(transform.rotation, TargetRotation, KnockbackRotationSpeed * Time.deltaTime);
            transform.rotation = EntRotation;
        }

        if (IsGrounded)
        {
            if (EntityRB.velocity.magnitude < 0.2f)
            {
                IsEnemyKnockedBack = false;
            }
        }
    }
}
