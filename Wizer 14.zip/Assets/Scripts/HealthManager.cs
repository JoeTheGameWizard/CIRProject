using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

[System.Serializable]
public class Damage
{
    public DamageType type;
    public Color DamageColor;
}

public enum DamageType
{
    Fire,
    Slashing,
    Piercing,
    Bludgeoning
}

public class HealthManager : MonoBehaviour
{
    public Damage[] DmgTypes;

    public Dictionary<DamageType, Damage> DmgDictionary = new Dictionary<DamageType, Damage>();

    public GameObject TextObject;

    private void Start()
    {
        foreach(var dmg in DmgTypes)
        {
            DmgDictionary.Add(dmg.type, dmg);
        }
    }

    public void DoDamageNumbers(int Damage, DamageType DmgType, Vector3 Location)
    {
        GameObject TextMesh = Instantiate(TextObject.gameObject, Location, Quaternion.identity);
        TMP_Text Texttext = TextMesh.transform.GetChild(0).GetComponentInChildren<TMP_Text>();      
        Damage dmg;
        DmgDictionary.TryGetValue(DmgType, out dmg);
        Texttext.text = "" + Damage;
        Texttext.color = dmg.DamageColor;
    }
}
