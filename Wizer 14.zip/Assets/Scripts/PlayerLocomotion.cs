using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerLocomotion : MonoBehaviour
{
    [Header("Falling")]
    [SerializeField]
    private float FallingDrag;
    public float LongFallVelocity;
    [SerializeField]
    private float GravityMultiplier;
    public float inAirTimer;
    public bool IsLongFall;
    public Transform feet;
    public LayerMask groundLayers;

    [Header("Movement flags")]
    public bool IsSprinting;
    public bool IsGrounded;
    public bool IsJumping;

    [Header("Jump Speeds")]
    [SerializeField]
    private float jumpHeight = 3;
    [SerializeField]
    private float gravityIntensity = -15;

    [SerializeField]
    private Transform cameraObject;
    [SerializeField]
    private Rigidbody PlayerRB;
    [SerializeField]
    private float WalkingSpeed = 2.5f;
    [SerializeField]
    private float SprintingSpeed = 7f;
    [SerializeField]
    private float RotationSpeed = 15f;

    [Header("Floating")]
    public bool IsFloating = false;
    [SerializeField]
    private float FloatSpeed;
    [SerializeField]
    private float MaxFloatSpeed;
    [SerializeField]
    private float FloatRotationSpeed;

    private ManagePlayerAnimations AnimManager;
    private Vector3 MoveDirection;
    private PlayerManager Manager;
    private InputManager inputManager;
    private PlayerMagic magik;

    private void Awake()
    {
        inputManager = GetComponent<InputManager>();
        PlayerRB = GetComponent<Rigidbody>();
        cameraObject = Camera.main.transform;
        Manager = GetComponent<PlayerManager>();
        AnimManager = GetComponent<ManagePlayerAnimations>();
        magik = GetComponent<PlayerMagic>();
    }

    public void HandleAllMovement()
    {
        if (!IsFloating)
        {
            HandleFallingAndLanding();
        }
        if (Manager.isInteracting) { PlayerRB.velocity = Vector3.zero; return; }
        HandleMovement();
        HandleRotation();
        HandleFloating();
        HandleJumping();
    }

    private void HandleMovement()
    {
        if (IsFloating)
        {
            Vector3 Camf = new Vector3(cameraObject.forward.x, cameraObject.forward.y, cameraObject.forward.z);
            Vector3 Camr = new Vector3(cameraObject.right.x, cameraObject.right.y, cameraObject.right.z);
            MoveDirection = Camf.normalized * inputManager.verticalInput;
            MoveDirection = MoveDirection + Camr.normalized * inputManager.horizontalInput;
            MoveDirection.Normalize();
            if ((PlayerRB.velocity + (MoveDirection * FloatSpeed * Time.deltaTime)).magnitude < MaxFloatSpeed)
            {
                PlayerRB.velocity += MoveDirection * FloatSpeed * Time.deltaTime;
            }
        }
        else
        {
            Vector3 Camf = new Vector3(cameraObject.forward.x, 0f, cameraObject.forward.z);
            Vector3 Camr = new Vector3(cameraObject.right.x, 0f, cameraObject.right.z);
            MoveDirection = Camf.normalized * inputManager.verticalInput;
            MoveDirection = MoveDirection + Camr.normalized * inputManager.horizontalInput;
            MoveDirection.Normalize();

            if (IsSprinting)
            {
                MoveDirection = MoveDirection * SprintingSpeed;
            }
            else
            {
                MoveDirection = MoveDirection * WalkingSpeed;
            }
            Vector3 movementVelocity = new Vector3(MoveDirection.x, PlayerRB.velocity.y, MoveDirection.z);
            if (IsGrounded)
            {
                PlayerRB.velocity = movementVelocity;
            }
            else
            {
                PlayerRB.velocity += (movementVelocity / (inAirTimer + 1.1f)) * Time.deltaTime;
            }
        }
    }

    private void HandleRotation()
    {
        Vector3 TargetDirection = Vector3.zero;
        if (!IsFloating)
        {
            TargetDirection = cameraObject.forward * inputManager.verticalInput;
            TargetDirection = TargetDirection + cameraObject.right * inputManager.horizontalInput;
            TargetDirection.Normalize(); 

            TargetDirection.y = 0;
        }
        else
        {
            TargetDirection = cameraObject.forward;
        }

        if (TargetDirection == Vector3.zero)
            if (transform.rotation.x == 0)
                TargetDirection = transform.forward;

        Quaternion TargetRotation = Quaternion.LookRotation(TargetDirection);
        Quaternion PlayerRotation = Quaternion.Slerp(transform.rotation, TargetRotation, RotationSpeed * Time.deltaTime);
        transform.rotation = PlayerRotation;
    }

    private void HandleFallingAndLanding()
    {
        IsGrounded = Physics.CheckSphere(feet.position, 0.4f, groundLayers);
        if (PlayerRB.velocity.y <= 0.1f)
        {
            IsJumping = false;
        }
        else
        {
            Vector3 ArtificialDrag = PlayerRB.velocity * FallingDrag;
            ArtificialDrag.y = 0f;
            PlayerRB.velocity -= ArtificialDrag;
        }
        if (!IsGrounded && !IsJumping)
        {
            inAirTimer = inAirTimer + Time.deltaTime;
            PlayerRB.AddForce(-Vector3.up * inAirTimer * GravityMultiplier);
        }
        else
        {
            inAirTimer = 0;
        }
    }

    public void HandleJumping()
    {   if (inputManager.JumpInput == true)
        {
            if (IsFloating)
            {
                Vector3 movementVelocity = cameraObject.up;
                if ((PlayerRB.velocity + movementVelocity * FloatSpeed * Time.deltaTime).magnitude < MaxFloatSpeed)
                {
                    PlayerRB.velocity += movementVelocity * FloatSpeed * Time.deltaTime;
                }
            }
            else
            {
                if (IsGrounded)
                {
                    inputManager.JumpInput = false;
                    Debug.Log("Jump!");
                    IsJumping = true;
                    float jumpingVelocity = Mathf.Sqrt(-2 * gravityIntensity * jumpHeight);
                    Vector3 PlayerVelocity = MoveDirection;
                    PlayerVelocity.y = jumpingVelocity;
                    PlayerRB.velocity = PlayerVelocity;
                }
            }
        }

    }

    private void HandleFloating()
    {
        if(inputManager.FloatInput == true)
        {
            IsFloating = true;
            PlayerRB.useGravity = false;
        }
        else
        {
            if (magik.CastingMagic == false)
            {
                IsFloating = false;
                PlayerRB.useGravity = true;
            }
        }
    }
}
