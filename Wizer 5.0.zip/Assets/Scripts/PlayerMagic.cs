using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMagic : MonoBehaviour
{
    public float MaxMoonlight;
    public float CurrentMoonlight;
    [SerializeField]
    private float MoonLightChargeRate;

    private bool CastingMagic = false;

    void Start()
    {
        
    }

    void Update()
    {
        
    }

    public void CastSpell()
    {
        Debug.Log("Cast spell!!!");
    }
}
