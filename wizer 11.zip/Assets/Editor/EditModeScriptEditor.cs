using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class EditModeScriptEditor : Editor
{
    
}

[CustomEditor(typeof(Chunk))]
public class ChunkEditor : Editor
{
    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("Remesh Chunk"))
        {
            var chunkk = (Chunk)target;
            chunkk.CombineBlocks();
        }

        if (GUILayout.Button("Seperate Chunk"))
        {
            var chunkk = (Chunk)target;
            chunkk.UnCombineBlocks();
        }
        base.OnInspectorGUI();
    }
}

[CustomEditor(typeof(WorldManager))]
public class WorldManagerEditor : Editor
{
    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("Sort Blocks - (DO NOT SORT WHILE SEPERATED)"))
        {
            var WManager = (WorldManager)target;
            WManager.SortCubesEditMode();
        }

        if (GUILayout.Button("Mesh All Chunks"))
        {
            var WManager = (WorldManager)target;
            WManager.MeshAllChunks();
        }

        if (GUILayout.Button("Seperate All Chunks"))
        {
            var WManager = (WorldManager)target;
            WManager.UnMeshAllChunks();
        }

        if (GUILayout.Button("Update Dictionary"))
        {
            var WManager = (WorldManager)target;
            WManager.UpdateDictionary();
        }

        if (GUILayout.Button("Clear Chunks - remember to delete chunk objects manually"))
        {
            var WManager = (WorldManager)target;
            WManager.ClearChunks();
        }
        base.OnInspectorGUI();
    }
}
