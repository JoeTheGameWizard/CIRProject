using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MakeExplosion : MonoBehaviour
{
    [SerializeField]
    private float ExplosionRadius;
    [SerializeField]
    private float ExplosionForce;
    [SerializeField]
    private float EnvironmentDamage;
    [SerializeField]
    private float EntityDamage;
    [SerializeField]
    private float DestroyTime;

    private BlockManager blockManager;

    void Start()
    {
        blockManager = FindFirstObjectByType<BlockManager>();
        Explode();
        Destroy(this.gameObject, DestroyTime);
    }

    private void Explode()
    {
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, ExplosionRadius);
        foreach (var hitCollider in hitColliders)
        {
            if (hitCollider.GetComponent<ChunkMesh>())
            {
                Chunk chunk = hitCollider.GetComponent<ChunkMesh>().ParentChunk;
                Vector3Int[] blocksToDestroy = blockManager.GetBlockSphere(transform.position, ExplosionRadius);
                chunk.DestroyBlocks(blocksToDestroy, EnvironmentDamage);
                Debug.Log("Destroy blocks?");
            }
            if (hitCollider.GetComponent<EntityHealth>())
            {
                EntityHealth Helth = hitCollider.GetComponent<EntityHealth>();
                Vector3 Direction = hitCollider.transform.position - transform.position;
                Helth.DoKnockBack(Direction, ExplosionForce);
            }
            if (hitCollider.GetComponent<ActiveCube>())
            {
                ActiveCube activeCube = hitCollider.GetComponent<ActiveCube>();
                Vector3 Direction = hitCollider.transform.position - transform.position;
                activeCube.FlingSelf(Direction.normalized, ExplosionForce);
            }
        }
    }

    void Update()
    {
        
    }
}
