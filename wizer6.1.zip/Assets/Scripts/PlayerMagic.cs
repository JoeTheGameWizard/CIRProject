using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerMagic : MonoBehaviour
{
    public float MaxMoonlight;
    public float CurrentMoonlight;
    public float MoonLightChargeRate;
    public float MoonLightDecayRate;
    public SpellScript SelectedSpell;
    public GameObject CurrentSpell;
    public SpellScript CurrentSpellScript;
    public Transform OrbLocation;
    [SerializeField]
    private Image ManaBar;
    [SerializeField]
    private LayerMask RayLayers;
    [SerializeField]
    private Transform CameraTransform;
    [SerializeField]
    private Animator PlayerAnim;

    public Vector3 Direction;

    private PlayerLocomotion loco;
    private InputManager innie;
    public bool CastingMagic = false; 

    void Awake()
    {
        loco = GetComponent<PlayerLocomotion>();
        innie = GetComponent<InputManager>();
    }

    void Update()
    {
        ManaBar.fillAmount = CurrentMoonlight / MaxMoonlight;
        RaycastHit hit;
        if (Physics.Raycast(CameraTransform.position, CameraTransform.forward, out hit, Mathf.Infinity, RayLayers))
        {
            Direction = hit.point - OrbLocation.position;
        }
        else
        {
            Direction = CameraTransform.forward;
        }    

        if (loco.IsFloating)
        {
            if (CastingMagic == false)
            {
                if (innie.CastInput == true)
                {
                    CastSpell();
                }
                if (innie.EndCastInput == true && innie.CastInput == true)
                {
                    EndSpell();
                }

                if (CurrentMoonlight < MaxMoonlight)
                {
                    CurrentMoonlight += MoonLightChargeRate * Time.deltaTime;
                }
                else
                {
                    CurrentMoonlight = MaxMoonlight;
                }
            }
            else
            {
                innie.CastInput = false;
                innie.EndCastInput = false;
            }
        }
        else
        {
            if (CurrentMoonlight > 0)
            {
                CurrentMoonlight -= MoonLightDecayRate * Time.deltaTime;
            }
            else
            {
                CurrentMoonlight = 0;
            }
        }

        if (CurrentSpellScript != null)
        {
            if (CurrentSpellScript.SpellCompleted == true)
            {
                CastingMagic = false;
            }
        }
    }

    public void CastSpell()
    {
        //remember to fix this later, it will break functionality for hold and release spells
        if (SelectedSpell.ManaCost < CurrentMoonlight)
        {
            CurrentMoonlight -= SelectedSpell.ManaCost;
        }
        else
        {
            innie.CastInput = false;
            innie.EndCastInput = false;
            return;
        }
        CastingMagic = true;
        CurrentSpell = Instantiate(SelectedSpell.gameObject, OrbLocation.position, Quaternion.identity);
        CurrentSpellScript = CurrentSpell.GetComponent<SpellScript>();
        CurrentSpellScript.PlayerSource = this;
        PlayerAnim.Play(CurrentSpellScript.StartAnim.name);
        CurrentSpellScript.BeginSpell();

        if (CurrentSpellScript.ButtonReleaseSpell == false)
        {
            innie.CastInput = false;
        }
    }

    public void EndSpell()
    {
        if (SelectedSpell.ManaCost < CurrentMoonlight)
        {
        }
        else
        {
            innie.CastInput = false;
            innie.EndCastInput = false;
            return;
        }
        PlayerAnim.Play(CurrentSpellScript.EndAnim.name);
        CurrentSpellScript.FinishSpell();
        innie.CastInput = false;
        innie.EndCastInput = false;
    }
}
