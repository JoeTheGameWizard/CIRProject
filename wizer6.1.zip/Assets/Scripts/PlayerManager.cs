using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerManager : MonoBehaviour
{
    Animator anim;
    InputManager inputManager;
    CameraManager camManager;
    PlayerLocomotion playerLoco;

    public bool isInteracting;

    private void Awake()
    {
        camManager = FindFirstObjectByType<CameraManager>();
        inputManager = GetComponent<InputManager>();
        playerLoco = GetComponent<PlayerLocomotion>();
        anim = GetComponentInChildren<Animator>();
    }

    private void Update()
    {
        inputManager.HandleAllInputs();
    }

    private void FixedUpdate()
    {
        playerLoco.HandleAllMovement();
    }

    private void LateUpdate()
    {
        camManager.HandleAllCameraMovement();


        isInteracting = anim.GetBool("IsInteracting");

    }
}
