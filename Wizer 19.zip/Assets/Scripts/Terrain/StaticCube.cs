using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class StaticCube : MonoBehaviour
{
    public Vector3Int Cords = new Vector3Int();
    BlockManager blockManager;
    public string BlockID = "Default";

    [Space(10)]

    public float Durability;
    [Tooltip("This boolean value dictates wether or not the block will take damage. if set to true," +
        "the block will lose durability when it is damaged. if it is not, the block will only be" +
        "destroyed when the damage taken is greater than the durability")]
    [SerializeField]
    private bool TakesDamage;
    [SerializeField] 
    private GameObject ActiveCubee;
    [Space(10)]
    [SerializeField]
    private GameObject CurrentActiveCube;
    private ActiveCube CubeScript;

    void Awake()
    {
        if (Application.isPlaying)
        {
            blockManager = FindFirstObjectByType<BlockManager>();
            DisplayCoords();

            if (CurrentActiveCube == null)
            {
                CurrentActiveCube = Instantiate(ActiveCubee, transform.position, transform.rotation);
                CubeScript = CurrentActiveCube.GetComponent<ActiveCube>();
                CurrentActiveCube.SetActive(false);
            }
        }
    }

    [ContextMenu("Display Coords")]
    public void DisplayCoords()
    {
        if (!Application.isPlaying)
        {
            blockManager = FindFirstObjectByType<BlockManager>();
        }
        if (!blockManager) return;
        Cords.x = Mathf.RoundToInt(transform.position.x / blockManager.UnityGridSize);
        Cords.y = Mathf.RoundToInt(transform.position.y / blockManager.UnityGridSize);
        Cords.z = Mathf.RoundToInt(transform.position.z / blockManager.UnityGridSize);
        if (blockManager.Grid.ContainsKey(Cords))
        {
            if (Application.isPlaying)
            {
                //Destroy(this.gameObject);
            }
            else
            {
                //DestroyImmediate(this.gameObject);
            }
        }
        else
        {
            blockManager.Grid.Add(Cords, BlockID);
        }
    }

    public void DealDamage(float DamageTaken, Vector3 brokenvelocity)
    {
        if (TakesDamage == true)
        {
            Durability -= DamageTaken;
            if (Durability <= 0)
            {
                CurrentActiveCube.transform.position = transform.position;
                CurrentActiveCube.transform.rotation = Quaternion.identity;
                CurrentActiveCube.SetActive(true);
                CubeScript.FlingSelf(brokenvelocity);
                blockManager.Grid.Remove(Cords);
                blockManager.RePoolBlock(this.gameObject, BlockID);
            }
        }
        else
        {
            if (Durability < DamageTaken)
            {
                CurrentActiveCube.transform.position = transform.position;
                CurrentActiveCube.transform.rotation = Quaternion.identity;
                CurrentActiveCube.SetActive(true);
                CubeScript.FlingSelf(brokenvelocity);
                blockManager.RePoolBlock(this.gameObject, BlockID);
            }
        }
    }
}
