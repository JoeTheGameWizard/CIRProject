using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillEnemiesInBounds : MonoBehaviour
{
    void OnTriggerEnter(Collider other)
    {
        if (other.GetComponent<EntityHealth>())
        {
            other.GetComponent<EntityHealth>().DoDamage(9999, DamageType.Force);
        }
        if (other.GetComponent<PlayerHealth>())
        {
            other.GetComponent<PlayerHealth>().TakeDamage(9999, DamageType.Force);
        }
    }
}
