using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

[System.Serializable]
public class Damage
{
    public DamageType type;
    public Color DamageColor;
}

public enum Effectiveness
{
    Neutral,
    Vunerable,
    Resistant,
    Immune
}

public enum DamageType
{
    Fire,
    Slashing,
    Piercing,
    Bludgeoning,
    Force
}

public class HealthManager : MonoBehaviour
{
    public Damage[] DmgTypes;

    public Dictionary<DamageType, Damage> DmgDictionary = new Dictionary<DamageType, Damage>();

    public GameObject TextObject;

    private void Start()
    {
        foreach(var dmg in DmgTypes)
        {
            DmgDictionary.Add(dmg.type, dmg);
        }
    }

    public void DoDamageNumbers(int Damage, DamageType DmgType, Vector3 Location, Effectiveness Effective)
    {
        GameObject TextMesh = Instantiate(TextObject.gameObject, Location, Quaternion.identity);
        TMP_Text Texttext = TextMesh.transform.GetChild(0).GetComponentInChildren<TMP_Text>();
        Damage dmg;
        DmgDictionary.TryGetValue(DmgType, out dmg);
        if (Effective == Effectiveness.Neutral)
        {         
            Texttext.text = "" + Damage;
            Texttext.color = dmg.DamageColor;
        }
        if (Effective == Effectiveness.Vunerable)
        {
            Texttext.text = "" + Damage + "!!!";
            Texttext.color = dmg.DamageColor;
        }
        if (Effective == Effectiveness.Resistant)
        {
            Texttext.text = "" + Damage + "...";
            Texttext.color = dmg.DamageColor;
        }
        if (Effective == Effectiveness.Immune)
        {
            Texttext.text = "" + Damage + " :(";
            Texttext.color = Color.grey;
        }
    }
}
