using System.Collections;
using System.Collections.Generic;

using UnityEditor.Rendering;
using UnityEngine;

public class CameraManager : MonoBehaviour
{
    InputManager inputManager;

    [Header("Obj refs to camera + pivot + target")]
    [SerializeField]
    private Transform cameraPivot;//object ref to the camera pivot
    [SerializeField]
    private Transform cameraTransform;// object ref to the actual camera
    [SerializeField]
    private Transform targetTransform;

    [Header("Speeds for various things. pivot is up/down")]
    [SerializeField]
    private float FollowSpeed;
    [SerializeField]
    private float cameraLookSpeed = 2f;
    [SerializeField]
    private float cameraPivotSpeed = 2f;

    [Header("Settings for vertical movement and collision")]
    [SerializeField]
    private float minPivotAngle = -35f;
    [SerializeField]
    private float maxPivotAngle = 35f;
    [SerializeField]
    private float cameraCollisionRadius = 0.2f;
    [SerializeField]
    private float minCollisionOffset = 0.2f; //how much the camera jumps off of objects
    [SerializeField]
    private LayerMask collisionLayers;

    private Vector3 cameraFollowVelocity = Vector3.zero;
    private float defaultPosition;
    private float defaultPositionRoot;
    private Vector3 cameraVectorPosition;
    private Vector3 cameraPivotPosition;


    public float lookAngle;//up and down 
    public float pivotAngle;//left and right

    private void Awake()
    {
        inputManager = FindFirstObjectByType<InputManager>();
        targetTransform = FindFirstObjectByType<PlayerManager>().transform;
        defaultPosition = cameraTransform.localPosition.z;
        defaultPositionRoot = cameraPivot.localPosition.x;
    }
    
    public void HandleAllCameraMovement()
    {
        FollowTarget();
        RotateCamera();
        HandleCameraCollision();
    }

    private void FollowTarget()
    {
        Vector3 targetPosition = Vector3.SmoothDamp
            (transform.position, targetTransform.position, ref cameraFollowVelocity, FollowSpeed);
        transform.position = targetPosition;
    }

    private void RotateCamera()
    {
        Vector3 rotation;
        Quaternion targetRotation;

        lookAngle = lookAngle + (inputManager.cameraInputX * cameraLookSpeed);
        pivotAngle = pivotAngle + (inputManager.cameraInputY * cameraPivotSpeed);
        pivotAngle = Mathf.Clamp(pivotAngle, minPivotAngle, maxPivotAngle);

        rotation = Vector3.zero;
        rotation.y = lookAngle;
        targetRotation = Quaternion.Euler(rotation);
        transform.rotation = targetRotation;

        rotation = Vector3.zero;
        rotation.x = pivotAngle;
        targetRotation = Quaternion.Euler(rotation);
        cameraPivot.localRotation = targetRotation;
    }

    private void HandleCameraCollision()
    {
        float targetPosition = defaultPosition;
        float targetPositionRoot = defaultPositionRoot;
        RaycastHit hit;
        RaycastHit hit2;
        Vector3 direction = cameraTransform.position - cameraPivot.position;
        Vector3 direction2 = cameraPivot.position - transform.position;
        direction.Normalize();
        direction2.Normalize();

        if (Physics.SphereCast(cameraPivot.transform.position, cameraCollisionRadius, direction, out hit, Mathf.Abs(targetPosition), collisionLayers))
        {
            float distance = Vector3.Distance(cameraPivot.position, hit.point);
            targetPosition = -(distance - cameraCollisionRadius);
        }

        if (Mathf.Abs(targetPosition) < minCollisionOffset)
        {
            targetPosition = targetPosition - minCollisionOffset;
        }

        if (Physics.SphereCast(transform.position, cameraCollisionRadius, direction2, out hit2, Mathf.Abs(targetPositionRoot), collisionLayers))
        {
            float distance = Vector3.Distance(transform.position, hit2.point);
            targetPositionRoot = (distance - cameraCollisionRadius);
        }

        if (Mathf.Abs(targetPositionRoot) < minCollisionOffset)
        {
            targetPositionRoot = targetPositionRoot + minCollisionOffset;
        }

        cameraVectorPosition.z = Mathf.Lerp(cameraTransform.localPosition.z, targetPosition, 0.2f);
        cameraTransform.localPosition = cameraVectorPosition;

        cameraPivotPosition.x = Mathf.Lerp(cameraPivot.localPosition.x, targetPositionRoot, 0.2f);
        cameraPivot.localPosition = cameraPivotPosition;
    }
}
