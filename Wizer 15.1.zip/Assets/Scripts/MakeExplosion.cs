using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

public class MakeExplosion : MonoBehaviour
{
    [SerializeField]
    private float ExplosionRadius;
    [SerializeField]
    private float ExplosionForce;
    [SerializeField]
    private float EnvironmentDamage;
    [SerializeField]
    private float EntityDamage;
    [SerializeField]
    private DamageType dmgType;
    [SerializeField]
    private float DestroyTime;
    [SerializeField]
    private AnimationCurve ExplosionFalloff;

    private BlockManager blockManager;

    void Start()
    {
        blockManager = FindFirstObjectByType<BlockManager>();
        Explode();
        Destroy(this.gameObject, DestroyTime);
    }

    private void Explode()
    {
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, ExplosionRadius);
        foreach (var hitCollider in hitColliders)
        {
            if (hitCollider.GetComponent<ChunkMesh>())
            {
                Chunk chunk = hitCollider.GetComponent<ChunkMesh>().ParentChunk;
                List<Vector3Int> blocksToDestroy = blockManager.GetBlockSphere(transform.position, ExplosionRadius).ToList();
                List <float> Damage = new List<float>();
                List<Vector3> blockVelocity = new List<Vector3>();
                foreach (var blockToDestroy in blocksToDestroy)
                {
                    Vector3 blockPosition = blockToDestroy;
                    blockPosition = blockPosition / 2f; 
                    Vector3 delta = ((blockPosition) - transform.position);
                    Damage.Add((ExplosionFalloff.Evaluate(delta.magnitude / ExplosionRadius)) * EnvironmentDamage);
                    blockVelocity.Add(delta.normalized * ExplosionForce);
                }
                chunk.DestroyBlocks(blocksToDestroy, Damage.ToArray(), blockVelocity);
            }
            if (hitCollider.GetComponent<EntityHealth>())
            {
                EntityHealth Helth = hitCollider.GetComponent<EntityHealth>();
                Vector3 Direction = hitCollider.transform.position - transform.position;
                Helth.DoKnockBack(Direction, ExplosionForce);
                Helth.DoDamage(Mathf.RoundToInt(ExplosionFalloff.Evaluate(Direction.magnitude / ExplosionRadius) * EntityDamage), dmgType);
            }
            if (hitCollider.GetComponent<PlayerHealth>())
            {
                PlayerHealth helt = hitCollider.GetComponent<PlayerHealth>();
                Vector3 Direction = hitCollider.transform.position - transform.position;
                helt.TakeDamage(Mathf.RoundToInt(ExplosionFalloff.Evaluate(Direction.magnitude / ExplosionRadius) * EntityDamage), dmgType);
            }
            if (hitCollider.GetComponent<ActiveCube>())
            {
                ActiveCube activeCube = hitCollider.GetComponent<ActiveCube>();
                Vector3 Direction = hitCollider.transform.position - transform.position;
                activeCube.FlingSelf(Direction.normalized * ExplosionForce);
                activeCube.DamageCube(ExplosionFalloff.Evaluate(Direction.magnitude / ExplosionRadius) * EnvironmentDamage);
            }
        }
    }

    void Update()
    {
        
    }
}
