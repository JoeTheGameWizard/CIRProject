using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class SpellProjectile : MonoBehaviour
{
    public SpellScript SpellParent;

    [SerializeField]
    private float ProjectileSpeed;
    [SerializeField]
    private GameObject SpawnObjectOnHit;
    [SerializeField]
    private bool DestroyOnImpact;
    [SerializeField]
    private bool RotateDirection;
    [SerializeField]
    private GameObject RotateMesh;

    private Vector3 FireDirection;
    private Rigidbody rb;
    private bool IsMoving; 

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }


    public void StartMoving()
    {
        IsMoving = true;
        FireDirection = SpellParent.SpellDirection;
    }

    void FixedUpdate()
    {
        if (RotateDirection)
        {
            RotateMesh.transform.rotation = Quaternion.LookRotation(-FireDirection);
        }  
        if (IsMoving)
        {
            rb.velocity = FireDirection.normalized * ProjectileSpeed;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        Instantiate(SpawnObjectOnHit, transform.position, Quaternion.identity);
        if (DestroyOnImpact)
        {
            Destroy(this.gameObject);
        }
    }
}
