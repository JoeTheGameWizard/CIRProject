using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MakeExplosion : MonoBehaviour
{
    [SerializeField]
    private float ExplosionRadius;
    [SerializeField]
    private float ExplosionForce;
    [SerializeField]
    private float EnvironmentDamage;
    [SerializeField]
    private float EntityDamage;
    [SerializeField]
    private float DestroyTime;


    void Start()
    {
        StartCoroutine(nameof(Explode));
        Destroy(this.gameObject, DestroyTime);
    }

    IEnumerator Explode()
    {
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, ExplosionRadius);
        foreach (var hitCollider in hitColliders)
        {
            if (hitCollider.GetComponent<ChunkMesh>())
            {
                hitCollider.GetComponent<ChunkMesh>().ParentChunk.UnCombineBlocks();
            }        
        }

        yield return null;

        Collider[] hitColliders2 = Physics.OverlapSphere(transform.position, ExplosionRadius);
        foreach (var hitCollider2 in hitColliders2)
        {
            if (hitCollider2.GetComponent<EntityHealth>())
            {
                EntityHealth Helth = hitCollider2.GetComponent<EntityHealth>();
                Vector3 Direction = hitCollider2.transform.position - transform.position;
                Helth.DoKnockBack(Direction, ExplosionForce);
            }
            else if (hitCollider2.GetComponent<StaticCube>())
            {
                StaticCube staticCube = hitCollider2.GetComponent<StaticCube>();
                Vector3 Direction = hitCollider2.transform.position - transform.position;
                staticCube.DealDamage(EnvironmentDamage, Direction.normalized * ExplosionForce);
            }
            else if (hitCollider2.GetComponent<ActiveCube>())
            {
                ActiveCube activeCube = hitCollider2.GetComponent<ActiveCube>();
                Vector3 Direction = hitCollider2.transform.position - transform.position;
                activeCube.FlingSelf(Direction.normalized, ExplosionForce);
            }
        }
    }

    void Update()
    {
        
    }
}
