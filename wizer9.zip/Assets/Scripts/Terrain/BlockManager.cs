using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockManager : MonoBehaviour
{
    public float UnityGridSize;

    Dictionary<Vector3Int, string> grid = new Dictionary<Vector3Int, string>();
    public Dictionary<Vector3Int, string> Grid { get { return grid; } }
    public Material BlockMaterial;

    // Object pooling
    private static Dictionary<string, Queue<GameObject>> BlockPool2 = new Dictionary<string, Queue<GameObject>>();
    public List<Queue<GameObject>> BlockPool = new List<Queue<GameObject>>();
    public List<BlockType> blockTypes = new List<BlockType>();
    public int PoolSize = 50;
    public int MaxPoolSize = 1000;

    private void Awake()
    {
        InitialisePool();
    }

    private void InitialisePool()
    {
        foreach (var type in blockTypes)
        {
            Queue<GameObject> queue = new Queue<GameObject>();
            if (!BlockPool2.ContainsKey(type.BlockID))
            {
                BlockPool2.Add(type.BlockID, queue);
                for (int i = PoolSize; i > 0; i--)
                {
                    GameObject NewBlock = Instantiate(type.BlockPrefab, Vector3.zero, Quaternion.identity);
                    NewBlock.SetActive(false);
                    queue.Enqueue(NewBlock);
                }
            }
        }
        Debug.Log("The BlockPool has " + BlockPool2.Count + " types of blocks queued");
    }

    public GameObject GetPooledBlock(string blockID)
    {
        GameObject BlockObject = null;
        Queue<GameObject> queue;

        if (BlockPool2.TryGetValue(blockID, out queue))
        {
            if (queue.Count > 0)
            {
                BlockObject = queue.Dequeue();
            }
            else
            {
                BlockObject = Instantiate(blockTypes[0].BlockPrefab, Vector3.zero, Quaternion.identity);
            }
        }
        BlockObject.SetActive(true);
        return BlockObject;
    }

    public void RePoolBlock(GameObject BlockToQueue, string blocktype)
    {
        Queue<GameObject> queue;

        if (BlockPool2.TryGetValue(blocktype, out queue))
        {
            if (queue.Count < MaxPoolSize)
            {
                BlockToQueue.SetActive(false);
                queue.Enqueue(BlockToQueue);
            }
            else
            {
                Destroy(BlockToQueue);
            }
        }
    }

    public GameObject InstantiateBlock(string blockid)
    {
        int BlockIndex = 0;
        foreach (var blockType in blockTypes)
        {
            if (blockType.BlockID == blockid)
            {
                BlockIndex = blockTypes.IndexOf(blockType);
            }
        }
        GameObject newBlock = Instantiate(blockTypes[BlockIndex].BlockPrefab);

        return newBlock;
    }
}
