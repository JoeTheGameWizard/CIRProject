using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActiveCube : MonoBehaviour
{
    [SerializeField]
    Rigidbody rb;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    public void FlingSelf(Vector3 Direction, float Magnitude)
    {
        rb.velocity = Direction.normalized * Magnitude;
    }
}
