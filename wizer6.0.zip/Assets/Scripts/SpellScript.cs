using System.Collections;
using System.Collections.Generic;
using System.Xml.Serialization;
using UnityEngine;
using UnityEngine.Events;

public class SpellScript : MonoBehaviour
{
    public UnityEvent StartSpell;
    public AnimationClip StartAnim;
    [SerializeField]
    private float StartAnimDelay;

    [Header("Should the spell do anything when casting is released")]
    public bool ButtonReleaseSpell;

    public UnityEvent EndSpell;
    public AnimationClip EndAnim;
    [SerializeField]
    private float EndAnimDelay;

    public Vector3 SpellDirection;
    public GameObject SpellObject;
    public bool SpellCompleted;
    public PlayerMagic PlayerSource;
    public float ManaCost;

    public void BeginSpell()
    {
        Invoke(nameof(BeginSpellDelayed), StartAnimDelay);
        if (ButtonReleaseSpell == false)
        {
            Invoke(nameof(CompleteSpellComm), StartAnim.length);
        }
    }

    private void BeginSpellDelayed()
    {
        if (StartSpell != null)
        {
            SpellObject.SetActive(true);
            SpellDirection = PlayerSource.Direction;
            transform.position = PlayerSource.OrbLocation.position;
            StartSpell.Invoke();
        }
        else
        {
            Debug.Log("Spell is empty! please add the spell function to the event");
        }
    }

    public void FinishSpell()
    {
        Invoke(nameof(FinishSpellDelayed), EndAnimDelay);
    }

    private void FinishSpellDelayed()
    {
        if (EndSpell != null)
        {
            EndSpell.Invoke();
        }
    }

    private void CompleteSpellComm()
    {
        SpellCompleted = true;
    }
}
