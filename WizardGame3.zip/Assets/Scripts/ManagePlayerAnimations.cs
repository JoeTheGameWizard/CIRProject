using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManagePlayerAnimations : MonoBehaviour
{
    [SerializeField]
    private Animator PlayerAnim;
    [SerializeField]
    private InputManager InputManager;

    private PlayerLocomotion loco;

    private void Awake()
    {
        PlayerAnim = GetComponentInChildren<Animator>();
        InputManager = GetComponentInChildren<InputManager>();
        loco = GetComponent<PlayerLocomotion>();
    }
    private void Update()
    {
        if (InputManager.verticalInput != 0 || InputManager.horizontalInput != 0)
        {
            PlayerAnim.SetBool("IsMoving", true);
        }
        else
        {
            PlayerAnim.SetBool("IsMoving", false);
        }

        PlayerAnim.SetBool("IsSprinting", InputManager.SprintInput);
        PlayerAnim.SetBool("IsGrounded", loco.IsGrounded);
        PlayerAnim.SetBool("IsLongFall", loco.IsLongFall);
    }

    public void PlayTargetAnimation(string targetAnimation, bool isInteracting)
    {
        PlayerAnim.SetBool("IsInteracting", isInteracting);
        PlayerAnim.CrossFade(targetAnimation, 0.1f);
    }
}
