using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerLocomotion : MonoBehaviour
{
    [Header("Falling")]
    
    [SerializeField]
    private float LongFallTime;
    [SerializeField]
    private float GravityMultiplier;
    public float inAirTimer;
    public bool IsLongFall;
    public Transform feet;
    public LayerMask groundLayers;

    [Header("Movement flags")]
    public bool IsSprinting;
    public bool IsGrounded;
    public bool IsJumping;

    [Header("Jump Speeds")]
    [SerializeField]
    private float jumpHeight = 3;
    [SerializeField]
    private float gravityIntensity = -15;

    [SerializeField]
    private Transform cameraObject;
    [SerializeField]
    private Rigidbody PlayerRB;
    [SerializeField]
    private float WalkingSpeed = 2.5f;
    [SerializeField]
    private float SprintingSpeed = 7f;
    [SerializeField]
    private float RotationSpeed = 15f;

    private ManagePlayerAnimations AnimManager;
    private Vector3 MoveDirection;
    private PlayerManager Manager;
    private InputManager inputManager;

    private void Awake()
    {
        inputManager = GetComponent<InputManager>();
        PlayerRB = GetComponent<Rigidbody>();
        cameraObject = Camera.main.transform;
        Manager = GetComponent<PlayerManager>();
        AnimManager = GetComponent<ManagePlayerAnimations>();
    }

    public void HandleAllMovement()
    {
        HandleFallingAndLanding();
        if (Manager.isInteracting) { PlayerRB.velocity = Vector3.zero; return; }
        HandleMovement();
        HandleRotation();
    }

    private void HandleMovement()
    {
        MoveDirection = cameraObject.forward * inputManager.verticalInput;
        MoveDirection = MoveDirection + cameraObject.right * inputManager.horizontalInput;
        MoveDirection.Normalize();
        //MoveDirection.y = 0;
        if (IsSprinting && IsGrounded)
        {
            MoveDirection = MoveDirection * SprintingSpeed;
        }
        else
        {
            MoveDirection = MoveDirection * WalkingSpeed;
        }

        Vector3 movementVelocity = new Vector3(MoveDirection.x, PlayerRB.velocity.y, MoveDirection.z);
        PlayerRB.velocity = movementVelocity;
    }

    private void HandleRotation()
    {
        Vector3 TargetDirection = Vector3.zero;

        TargetDirection = cameraObject.forward * inputManager.verticalInput;
        TargetDirection = TargetDirection + cameraObject.right * inputManager.horizontalInput;
        TargetDirection.Normalize();
        TargetDirection.y = 0;

        if (TargetDirection == Vector3.zero)
            TargetDirection = transform.forward;

        Quaternion TargetRotation = Quaternion.LookRotation(TargetDirection);
        Quaternion PlayerRotation = Quaternion.Slerp(transform.rotation, TargetRotation, RotationSpeed * Time.deltaTime);
        transform.rotation = PlayerRotation;
    }

    private void HandleFallingAndLanding()
    {
        IsGrounded = Physics.CheckSphere(feet.position, 0.45f, groundLayers);
        if (PlayerRB.velocity.y <= 0)
        {
            IsJumping = false;
        }
        if (!IsGrounded && !IsJumping)
        {
            inAirTimer = inAirTimer + Time.deltaTime;
            PlayerRB.AddForce(-Vector3.up * inAirTimer);
            if (inAirTimer > LongFallTime)
            {
                IsLongFall = true;
            }
            else
            {
                IsLongFall = false;
            }
        }
        else
        {
            inAirTimer = 0;
            
        }
    }

    public void HandleJumping()
    {
        if (IsGrounded)
        {
            IsJumping = true;
            float jumpingVelocity = Mathf.Sqrt(-2 * gravityIntensity * jumpHeight);
            Vector3 PlayerVelocity = MoveDirection; 
            PlayerVelocity.y = jumpingVelocity;
            PlayerRB.velocity = PlayerVelocity;
        }
    }
}
